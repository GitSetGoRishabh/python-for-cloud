dayOfWeek=input("Enter the day of week : ").lower()
print(dayOfWeek)

if dayOfWeek=="saturday" or dayOfWeek=="sunday":
    print("Work harder boy!")
else:
    print("Practice")
