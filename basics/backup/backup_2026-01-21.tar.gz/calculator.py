num1=int(input("Enter a : "))
num2=int(input("Enter b : "))

sumNum=num1+num2

print(sumNum)