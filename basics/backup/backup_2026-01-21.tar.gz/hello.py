print("Hello World")
print("Hello i am rishabh")
yourname=input("Enter your name")
print("So your name is",yourname)